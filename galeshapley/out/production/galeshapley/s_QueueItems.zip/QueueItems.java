import java.util.ArrayList;

public class QueueItems {
    int uni_position;
    ArrayList<Integer> uni_pref;
    public QueueItems(int uni_position, ArrayList<Integer> uni_pref){
        this.uni_position = uni_position;
        this.uni_pref = uni_pref;
    }
    public QueueItems(){

    }
}
