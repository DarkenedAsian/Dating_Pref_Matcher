import java.util.ArrayList;

public class s_QueueItems {
    int s_position;
    ArrayList<Integer> s_pref;
    public s_QueueItems(int s_position, ArrayList<Integer> s_pref){
        this.s_position = s_position;
        this.s_pref = s_pref;
    }
    public s_QueueItems(){

    }
}
